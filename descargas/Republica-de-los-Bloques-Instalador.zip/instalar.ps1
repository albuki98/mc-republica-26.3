# Instalador de "Republica de los Bloques" (Minecraft 26.3 + Fabric) con actualizacion automatica.
# Se ejecuta UNA vez. Crea la carpeta de juego .minecraft\republica-26.3, deja el actualizador en
# republica-26.3\actualizador y crea el perfil "Republica de los Bloques 26.3" en el launcher oficial.
# Desde entonces, al pulsar Jugar el actualizador descarga solo los mods nuevos antes de arrancar.
# No borra nada: guarda copia del archivo de perfiles y aparta (no borra) los mods viejos.
$ErrorActionPreference='Stop'
function Paso($t){Write-Host "  $t"}
function Fallo($t){Write-Host "";Write-Host "  ERROR: $t" -ForegroundColor Red;exit 1}

$paquete=$PSScriptRoot
$origen=Join-Path $paquete 'actualizador'
foreach($f in 'republica-actualizador.jar','nucleo.jar'){if(-not (Test-Path -LiteralPath (Join-Path $origen $f))){Fallo 'Falta la carpeta "actualizador". Descomprime el ZIP con "Extraer todo" y ejecuta Instalar.bat desde la carpeta extraida.'}}
$mc=Join-Path $env:APPDATA '.minecraft'
if(-not (Test-Path -LiteralPath $mc)){Fallo "No encuentro $mc. Abre primero Minecraft 26.3 una vez desde el launcher oficial (PASO 1 de la guia)."}
$comprobar=-not $env:REPUBLICA_PRUEBA  # solo para pruebas del paquete
if($comprobar -and (Get-Process -Name 'MinecraftLauncher','Minecraft' -ErrorAction SilentlyContinue)){Fallo 'El launcher de Minecraft esta abierto. Cierralo del todo (tambien el juego) y vuelve a ejecutar Instalar.bat.'}
if($comprobar -and (Get-Process -Name 'javaw' -ErrorAction SilentlyContinue)){Fallo 'Minecraft parece estar abierto. Cierralo y vuelve a ejecutar Instalar.bat.'}

$versiones=@(Get-ChildItem -LiteralPath (Join-Path $mc 'versions') -Directory -ErrorAction SilentlyContinue | Where-Object {$_.Name -like 'fabric-loader-*-26.3'} | Sort-Object Name)
if($versiones.Count -eq 0){Fallo 'No encuentro Fabric para Minecraft 26.3. Haz el PASO 2 de la guia (instalador de Fabric, version 26.3) y vuelve a ejecutar esto.'}
$version=$versiones[-1].Name
Paso "Fabric encontrado: $version"

$juego=Join-Path $mc 'republica-26.3'
$destino=Join-Path $juego 'actualizador'
New-Item -ItemType Directory -Force -Path (Join-Path $juego 'mods'),$destino | Out-Null
Copy-Item -LiteralPath (Join-Path $origen 'republica-actualizador.jar') -Destination $destino -Force
# El nucleo se autoactualiza; solo se pone si no hay uno (o si el del paquete es mas nuevo que nada).
if(-not (Test-Path -LiteralPath (Join-Path $destino 'nucleo.jar'))){Copy-Item -LiteralPath (Join-Path $origen 'nucleo.jar') -Destination $destino}
Paso "Actualizador instalado en $destino"

# Los primeros paquetes (0.2.0) copiaban mods del servidor en la carpeta normal .minecraft\mods: se apartan.
$raiz=Join-Path $mc 'mods'
$apartados=Join-Path $mc 'mods-antiguos-republica'
if(Test-Path -LiteralPath $raiz){
 foreach($f in Get-ChildItem -LiteralPath $raiz -File | Where-Object {$_.Name -like 'cooperativa-*.jar' -or $_.Name -like 'chisel-fabric-*+mc26.3.jar' -or $_.Name -like 'cryonicconfig-fabric-*+mc26.3.jar' -or $_.Name -like 'mcarem-fabric-*+26.3.jar'}){
  New-Item -ItemType Directory -Force -Path $apartados | Out-Null
  Move-Item -LiteralPath $f.FullName -Destination $apartados -Force
  Paso "Apartado de la carpeta normal de mods: $($f.Name)"
 }
}
foreach($a in 'options.txt','servers.dat'){
 $o=Join-Path $mc $a;$d=Join-Path $juego $a
 if((Test-Path -LiteralPath $o) -and -not (Test-Path -LiteralPath $d)){Copy-Item -LiteralPath $o -Destination $d;Paso "Copiado tu $a"}
}

$memoria='-Xmx2G'
try{$ram=(Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory;if($ram -ge 15GB){$memoria='-Xmx4G'}elseif($ram -ge 7GB){$memoria='-Xmx3G'}}catch{}
$jvm="$memoria -XX:+UnlockExperimentalVMOptions -XX:+UseG1GC -javaagent:actualizador/republica-actualizador.jar"
$archivos=@(Get-ChildItem -LiteralPath $mc -Filter 'launcher_profiles*.json' -File -ErrorAction SilentlyContinue | Where-Object {$_.Name -match '^launcher_profiles(_microsoft_store)?\.json$'})
if($archivos.Count -eq 0){Fallo 'No encuentro los perfiles del launcher. Abre el launcher una vez, cierralo y vuelve a ejecutar esto.'}
$ahora=(Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
$icono=$null
$png=Join-Path $paquete 'icono.png'
if(Test-Path -LiteralPath $png){$icono='data:image/png;base64,'+[Convert]::ToBase64String([IO.File]::ReadAllBytes($png))}
foreach($pf in $archivos){
 try{
  $json=[IO.File]::ReadAllText($pf.FullName) | ConvertFrom-Json
  Copy-Item -LiteralPath $pf.FullName -Destination ($pf.FullName+'.antes-republica') -Force
  if(-not $json.profiles){$json | Add-Member -NotePropertyName profiles -NotePropertyValue ([pscustomobject]@{}) -Force}
  $perfil=[pscustomobject]@{name='Republica de los Bloques 26.3';type='custom';icon=$(if($icono){$icono}else{'Furnace'});lastVersionId=$version;gameDir=$juego;javaArgs=$jvm;created=$ahora;lastUsed=$ahora}
  $json.profiles | Add-Member -NotePropertyName 'republica-de-los-bloques' -NotePropertyValue $perfil -Force
  [IO.File]::WriteAllText($pf.FullName,($json | ConvertTo-Json -Depth 64),(New-Object Text.UTF8Encoding($false)))
  Paso "Perfil 'Republica de los Bloques 26.3' listo en $($pf.Name)"
 }catch{Fallo ("No se pudo editar $($pf.Name): $($_.Exception.Message)")}
}
Write-Host ""
Write-Host "  LISTO." -ForegroundColor Green
Write-Host "  Abre el launcher, elige 'Republica de los Bloques 26.3' junto al boton Jugar y pulsa Jugar."
Write-Host "  La primera vez descargara los mods (sale una ventanita con el progreso)."
Write-Host "  A partir de ahora se actualiza solo cada vez que juegues."
Write-Host "  Servidor: ambulance-highlands.tun.ply.gg:55034"
