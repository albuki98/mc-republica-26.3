@echo off
rem Ejecuta el instalador (instalar.ps1) que esta junto a este archivo.
echo.
echo  Republica de los Bloques - instalador (se actualiza solo despues)
echo  ----------------------------------------------------------------
if not exist "%~dp0instalar.ps1" (
  echo  No encuentro instalar.ps1. Descomprime primero el ZIP con "Extraer todo"
  echo  y ejecuta este archivo desde la carpeta extraida.
  goto fin
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
:fin
echo.
pause
